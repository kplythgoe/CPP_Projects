#include <iostream>
#include <limits>
#include <ctime>

using namespace std;

void guessing(int randomNumber, int lives, int guess, int difficultyChoice);
void replay();
void startGame();
int validation(int variableName);

int main() {
    startGame();
    return 0;
}

void guessing(int randomNumber, int lives, int guess, int difficultyChoice) {
    cin >> guess;
    if (guess == randomNumber) {
        cout << "\nCongratulation, you win!" << endl;
        replay();
    }
    else {
        lives--;
        if (lives == 0) {
            cout << "You have " << lives << " lives remaining - game over\n" <<endl;
            cout << "The answer was " << randomNumber << endl << endl;
            replay();
            return;
        }
        cout << "Wrong. You have " << lives << " lives remaining\n" << endl;
        if (difficultyChoice == 1) {
            if (guess > randomNumber) {
                cout << "Lower..." << endl;
            }
            else {
                cout << "Higher..." << endl;
            }
        }
        cout << "\nGuess again: ";
        guessing(randomNumber, lives, guess, difficultyChoice);
    }
}

void replay() {
        cout << "Would you like to play again?\n" << endl;
        cout << "1. Yes" << endl;
        cout << "2. No\n" << endl;
        int playAgain = 0;
        cout << "Please enter your choice by number from the options provided: ";
        playAgain = validation(playAgain);
        if (playAgain == 1) {
            startGame();
        }
        else {
            cout << "\nThank you for playing. Goodbye!" << endl;
        }
}

void startGame() {
    system("cls");
    srand((unsigned) time(0));
    int randomNumber = (rand() % 10) + 1;
    int lives = 3;
    int guess = 0;
    int difficultyChoice = 0;
    cout << "Welcome to the number guesser" << endl;
    cout << "Select your difficulty\n" << endl;
    cout << "1. Easy - tells the user whether the answer is higher or lower" << endl;
    cout << "2. Hard - doesn't give the user any prompts\n" << endl;
    cout << "Please enter your choice by number from the options provided: ";
    difficultyChoice = validation(difficultyChoice);
    cout << "\nYou have selected ";
    difficultyChoice == 1 ? cout << "easy difficulty\n\n" : cout << "hard difficulty\n\n";
    cout << "Guess the number between 1 - 10\n" << endl;
    cout << "You start the game with " << lives << " lives\n" << endl;
    cout << "Take a guess: ";
    guessing(randomNumber, lives, guess, difficultyChoice);
}

int validation(int variableName) {
    while(!(cin >> variableName) || (variableName != 1 && variableName != 2)) {
        cout << "Please enter your choice by number from the options provided: ";
        cin.clear(); 
        cin.ignore(numeric_limits<streamsize>::max(),'\n');
    }
    return variableName;
}