#include <iostream>
#include <limits>
#include <map>
#include <string>
#include <cctype>
#include <iomanip>
#include <cstdio>

using namespace std;

float round(float var);
float PAYE(float gross);
float NI(float gross);
string stringConversion(string &fullName);
void employeeCheck(map <string, float> employees, string fullName, int& matches);
void choiceVerification(int &another);
void intro(map <string, float> employees, int &matches);

int main() {
    
    map<string, float> employees;
    employees["JOHN SMITH"] = 18.25; employees["KIERAN LYTHGOE"] = 12.45; employees["JANE DOE"] = 15.75;
    int matches = 0;
    intro(employees, matches);
    return 0;
}

float round(float var) {
    // 37.66666 * 100 =3766.66
    // 3766.66 + .5 =3767.16    for rounding off value
    // then type cast to int so value is 3767
    // then divided by 100 so the value converted into 37.67
    float value = (int)(var * 100 + .5);
    return (float)value / 100;
}
float PAYE(float gross) {
    float threshold1 = 12571;
    float threshold2 = 50270;
    float threshold3 = 125140;
    float yearlyGross = gross*52;
    if (yearlyGross >= threshold1 && yearlyGross <= threshold2) {
        return ((yearlyGross - threshold1)*0.2)/52;
    }
    else if (yearlyGross > threshold2 && yearlyGross <= threshold3) {
        return (((yearlyGross - threshold2+1)*0.4) + ((threshold2 - threshold1)*0.2))/52;
    }
    else if(yearlyGross > threshold3) {
        return (((yearlyGross -threshold3)*0.45) + ((threshold3 - threshold2+1) * 0.4) + ((threshold2 - threshold1)*0.2))/52;
    }
    else {
        return 0;
    }
}
float NI(float gross) {
    float threshold1 = 242;
    float threshold2 = 967;
    if (gross >= threshold1 && gross <= threshold2) {
        return (gross - threshold1) * 0.1;
    }
    else if (gross > threshold2) {
        return ((gross - threshold2)*0.02 + (gross-threshold1)*0.1);
    }
    else {
        return 0;
    }
}
string stringConversion(string &fullName) {
    getline(cin, fullName);
    // Converting user input to uppercase
    for (char &c : fullName) { 
        c = toupper(c); 
    }
    return fullName;
}
void employeeCheck(map <string, float> employees, string fullName, int& matches) {
    map<string, float>::iterator it = employees.begin();
    it = employees.begin();
    while (it != employees.end()) {
        if(it->first == fullName) {
            matches++;
            cout << "\nSearching for " << fullName << " -> ";
            cout << matches << " match found\n" << endl;
            cout << "How many hours did you work: ";
            float hours;
            cin >> hours;
            float baseHours = (hours > 40) ? 40 : hours;
            float overtimeHours = (hours > 40) ? hours - 40 : 0;
            cout << endl;
            cout  << setw(it->first.length()) << left << "Name";
            cout  << setw(15) << right << "Hours Worked";
            cout  << setw(15) << right << "Base Pay";
            cout  << setw(20) << "Overtime Hours";
            cout  << setw(15) << "Overtime Pay";
            cout  << setw(20) << right << "Total Gross Pay" << left << endl;
            // OUTPUTTING EARNINGS
            cout << setw(85 + it->first.length()) << setfill('-') << "" << setfill(' ') << endl << endl;
            cout << setw(it->first.length()) << it->first;
            cout << setw(15) << right << baseHours;
            cout << setw(15) << fixed << setprecision(2) << it->second*baseHours;
            cout << setw(20) << overtimeHours;
            cout << setw(15) << overtimeHours * (it->second*1.5);
            float gross = (overtimeHours * (it->second*1.5)) + (it->second*baseHours);
            cout << setw(20) << gross << endl << endl;
            //OUTPUTTING TAX VALUES
            cout<< setw(85 + it->first.length()) << setfill('-') << "" << setfill(' ') << endl << endl;
            float paye = PAYE(it->second*baseHours);
            float ni = NI(it->second*baseHours);
            float pension = it->second*baseHours*0.05;
            cout << setw(78 + it->first.length()) << right << "PAYE Tax: " << setw(7) << paye << endl;
            cout << setw(78 + it->first.length()) << "National Insurance: " << setw(7) << ni << endl;
            cout << setw(78 + it->first.length()) << "Pension: " << setw(7) << pension << endl;
            cout<< setw(85 + it->first.length()) << setfill('-') << "" << setfill(' ') << endl << endl;
            cout << setw(78 + it->first.length()) << "Total Deductions: " << setw(7) << pension + paye + ni << endl;
            cout<< setw(85 + it->first.length()) << setfill('-') << "" << setfill(' ') << endl << endl;
            cout << setw(78 + it->first.length()) << right << "Net Pay: " << setw(7) << gross - (paye + ni + pension) << endl;
        } 
        it++;
    }
    if (matches == 0) {
        cout << "\nSearching for " << fullName << " -> ";
        cout << matches << " match found\n" << endl;
        cout << "Please enter another name: ";
        fullName = stringConversion(fullName);
        employeeCheck(employees, fullName, matches);
        return;
    }
    cout << "Would you like another estimate?\n" << endl;
        cout << "1. Yes" << endl;
        cout << "2. No\n" << endl;
        cout << "Please enter your choice by number from the options provided: ";
        int another = 0;
        choiceVerification(another);
        if (another == 1) {
            system("cls");
            cin.ignore();
            intro(employees, matches);
        }
        else {
            cout << "\nGoodbye" << endl;
            return;
        }
}
void choiceVerification(int &another) {
    while(!(cin >> another) || (another != 1 && another != 2)) {
        cout << "Please enter your choice by number from the options provided: ";
        cin.clear(); 
        cin.ignore(numeric_limits<streamsize>::max(),'\n');
    }
}
void intro(map <string, float> employees, int &matches) {
    matches = 0;
    cout << "Wage Calculator - for user reference, employees are named as follows: John Smith, Kieran Lythgoe, Jane Doe - Not case sensitive" << endl;
    cout << "------------------" << endl;
    cout << "Please enter your full name: ";
    string fullName;
    
    fullName = stringConversion(fullName);
    // Compaing user input with the names included in map
    employeeCheck(employees, fullName, matches);
}