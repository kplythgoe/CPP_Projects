#include <iostream>
#include <limits>
#include <chrono>
#include <thread>
#include <ctime>

using namespace std;

void addDelay(int milliseconds);
void validation();
void newRound(string username, int userCounter, int aiCounter, int roundNum);
void anotherGame(string username, int roundNum, int userCounter, int aiCounter);
void score(string username, int userCounter, int aiCounter);

int main() {
    cout << "Welcome to Rock, Paper, Scissors!" << endl;
    cout << "Please enter your name here: ";
    string username;
    cin >> username;
    cout << "\nDo know how to play Rock, Paper, Scissors?\n" << endl;
    cout << "1. Yes" << endl;
    cout << "2. No\n" << endl;
    cout << "Please select your choice by number: ";
    int help;
    while(!(cin >> help) || (help != 1 && help != 2)) {
        validation();
    }
    if (help == 2) {
        cout << "\nThe rules of Rock, Paper, Scissors are simple.\n" << endl;
        cout<< "Rock beats Scissors" << endl;
        cout<< "Scissors beats paper" << endl;
        cout<< "Paper beats rock\n" << endl;
        cout << "If the choice is the same, the result will be a draw\n" << endl;
        system("pause"); // For windows
    }
    
    cout << "\nGet ready to play in ";
    addDelay(1000);
    cout << "3 ";
    addDelay(1000);
    cout << "2 ";
    addDelay(1000);
    cout << "1 ";
    addDelay(1000);
    cout << "GO!";
    addDelay(1000);
    int userCounter = 0;
    int aiCounter = 0;
    int roundNum = 1;
    newRound(username, userCounter, aiCounter, roundNum);
    return 0;
}

void addDelay(int milliseconds) {
  this_thread::sleep_for(chrono::milliseconds(milliseconds));
}
void validation() {
        cout << "Please enter your choice by number from the options provided: ";
        cin.clear(); 
        cin.ignore(numeric_limits<streamsize>::max(),'\n');
}

void newRound(string username, int userCounter, int aiCounter, int roundNum) {
    system("cls");
    cout << "The game is best of 3 (meaning first to 2 points wins the game)\n" << endl;
    cout << "Round " << roundNum << endl;
    score(username, userCounter, aiCounter);
    cout << "Choose your weapon\n" << endl;
    cout << "1. Rock" << endl;
    cout << "2. Paper" << endl;
    cout << "3. Scissors\n" << endl;
    
    cout << "Please make your choice by number from the options provided: ";
    int userChoice;
    while(!(cin >> userChoice) || (userChoice != 1 && userChoice != 2 && userChoice != 3)) {
        validation();
    }
    cout << endl;
    if (userChoice == 1) {
        cout << "You have chosen Rock" << endl;
    }
    else if (userChoice == 2) {
        cout << "You have chosen Paper" << endl;
    }
    else {
        cout << "You have chosen Scissors" << endl;
    }
    
    srand((unsigned) time(0));
    int randomNumber = (rand() % 3) + 1;
    addDelay(1000);
    if (randomNumber == 1) {
        cout << "Opponent chosen Rock\n" << endl;
    }
    else if (randomNumber == 2) {
        cout << "Opponent has chosen Paper\n" << endl;
    }
    else {
        cout << "Opponent has chosen Scissors\n" << endl;
    }
    
    if ((userChoice == 1 && randomNumber == 3) || (userChoice == 2 && randomNumber == 1) || (userChoice == 3 && randomNumber == 2)) {
        cout << "You win this round" << endl;
        userCounter++;
    }
    else if ((userChoice == 1 && randomNumber == 2) || (userChoice == 2 && randomNumber == 3) || (userChoice == 3 && randomNumber == 1)) {
        cout << "You lose this round" << endl;
        aiCounter++;
    }
    else {
        cout << "This round is a draw" << endl;
    }
    roundNum++;
    cout << endl;
    if (userCounter == 2) {
        cout << "Congratulations, you win the game " << userCounter << " - " << aiCounter << endl;
        anotherGame(username, roundNum, userCounter, aiCounter);
        return;
    }
    else if (aiCounter == 2) {
        cout << "Unlucky! Your opponent has won the game " << aiCounter << " - " << userCounter << endl;
        anotherGame(username, roundNum, userCounter, aiCounter);
        return;
    }
    else {
        score(username, userCounter, aiCounter);
        cout << "Ready for round " << roundNum << "?\n" << endl;
        system("pause");
        newRound(username, userCounter, aiCounter, roundNum);
    }
}

void anotherGame(string username, int roundNum, int userCounter, int aiCounter) {
        cout << "\nWould you like to play again?\n" << endl;
        cout << "1. Yes" << endl;
        cout << "2. No\n" << endl;
        cout << "Please enter your choice by number from the options provided: ";
        int playAgain;
        while(!(cin >> playAgain) || (playAgain != 1 && playAgain != 2)) {
            validation();
        }
        if (playAgain == 1) {
            roundNum = 1;
            userCounter = 0;
            aiCounter = 0;
            newRound(username, userCounter, aiCounter, roundNum);
        }
        else {
            cout << "\nThanks for playing. Goodbye!" << endl;
        }
}

void score(string username, int userCounter, int aiCounter) {
    cout << "\nThe score is currently: " << username << " " << userCounter << " | " << aiCounter << " opponent\n" << endl; 
}