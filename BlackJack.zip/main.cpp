#include <algorithm>
#include <iostream>
#include <map>
#include <limits>
#include <chrono>
#include <thread>
#include <vector>
#include <ctime>

using namespace std;

void rules();
void enterChoiceMessage();
void choiceValidation(int &userChoice);
void dealCard(map<string, int> deck, map<string, int> &userHand, map<string, int> &dealerHand, map<string, int> &dealtTo, vector<int> &cardsDealt, int &userTotal, int &dealerTotal, bool &hold);
void result(int userTotal, int dealerTotal);
void reset(map<string, int> &userHand, map<string, int> &dealerHand, bool &dealerReveal, vector<int> &cardsDealt, int &userTotal, int &dealerTotal, bool &hold);
void addDelay(int milliseconds);
void showingHands(map<string, int> &userHand, map<string, int> &dealerHand, int &userTotal, int &dealerTotal, bool &hold);
void aceCheck(map<string, int> &userHand, map<string, int> &dealerHand, int &userTotal, int &dealerTotal);
bool highAceCheck(map<string, int> &turnsHand);

int main() {
    srand((unsigned) time(0));
    map<string, int> deck;
    map<string, int> userHand;
    map<string, int> dealerHand;
    // INSERTING ALL CARDS INTO THE DECK MAP
    // TEST DATA
//    deck["Two of Hearts"] = 1; deck["Three of Hearts"] = 1; deck["Four of Hearts"] = 1; deck["Five of Hearts"] = 1; deck["Six of Hearts"] = 1; deck["Seven of Hearts"] = 1; deck["Eight of Hearts"] = 1; deck["Nine of Hearts"] = 1; deck["Ten of Hearts"] = 1; deck["Jack of Hearts"] = 1; deck["Queen of Hearts"] = 1; deck["King of Hearts"] = 1; deck["Ace of Hearts"] = 1;
//    deck["Two of Hearts"] = 11; deck["Three of Hearts"] = 11; deck["Four of Hearts"] = 11; deck["Five of Hearts"] = 11; deck["Six of Hearts"] = 11; deck["Seven of Hearts"] = 11; deck["Eight of Hearts"] = 11; deck["Nine of Hearts"] = 11; 
    deck["Two of Hearts"] = 2; deck["Three of Hearts"] = 3; deck["Four of Hearts"] = 4; deck["Five of Hearts"] = 5; deck["Six of Hearts"] = 6; deck["Seven of Hearts"] = 7; deck["Eight of Hearts"] = 8; deck["Nine of Hearts"] = 9; deck["Ten of Hearts"] = 10; deck["Jack of Hearts"] = 10; deck["Queen of Hearts"] = 10; deck["King of Hearts"] = 10; deck["Ace of Hearts"] = 11;
    deck["Two of Diamonds"] = 2; deck["Three of Diamonds"] = 3; deck["Four of Diamonds"] = 4; deck["Five of Diamonds"] = 5; deck["Six of Diamonds"] = 6; deck["Seven of Diamonds"] = 7; deck["Eight of Diamonds"] = 8; deck["Nine of Diamonds"] = 9; deck["Ten of Diamonds"] = 10; deck["Jack of Diamonds"] = 10; deck["Queen of Diamonds"] = 10; deck["King of Diamonds"] = 10; deck["Ace of Diamonds"] = 11;
    deck["Two of Spades"] = 2; deck["Three of Spades"] = 3; deck["Four of Spades"] = 4; deck["Five of Spades"] = 5; deck["Six of Spades"] = 6; deck["Seven of Spades"] = 7; deck["Eight of Spades"] = 8; deck["Nine of Spades"] = 9; deck["Ten of Spades"] = 10; deck["Jack of Spades"] = 10; deck["Queen of Spades"] = 10; deck["King of Spades"] = 10; deck["Ace of Spades"] = 11;
    deck["Two of Clubs"] = 2; deck["Three of Clubs"] = 3; deck["Four of Clubs"] = 4; deck["Five of Clubs"] = 5; deck["Six of Clubs"] = 6; deck["Seven of Clubs"] = 7; deck["Eight of Clubs"] = 8; deck["Nine of Clubs"] = 9; deck["Ten of Clubs"] = 10; deck["Jack of Clubs"] = 10; deck["Queen of Clubs"] = 10; deck["King of Clubs"] = 10; deck["Ace of Clubs"] = 11;
    vector<int> cardsDealt{};
    int userTotal = 0;
    int dealerTotal = 0;
    bool dealerReveal = false;
    bool playAgain = true;
    bool hold = false;
    cout << "Welcome to the Blackjack table - do you know how to play Blackjack?\n" << endl;
    cout << "1. Yes" << endl;
    cout << "2. No" << endl;
    enterChoiceMessage();
    int userChoice = 0;
    choiceValidation(userChoice);
    if (userChoice == 2) {
        rules();
    }
    cout << endl;
    system("pause");
    while (playAgain) {
        system("cls");
        for (int i = 0; i < 2; i++) {
            dealCard(deck, userHand, dealerHand, userHand, cardsDealt, userTotal, dealerTotal, hold);
            dealCard(deck, userHand, dealerHand, dealerHand, cardsDealt, userTotal, dealerTotal, hold);
        }
        showingHands(userHand, dealerHand, userTotal, dealerTotal, hold);
        while (userTotal > 21 && highAceCheck(userHand)) {
        aceCheck(userHand, dealerHand, userTotal, dealerTotal);
        showingHands(userHand, dealerHand, userTotal, dealerTotal, hold);
        }
        while (!hold && userTotal != 21) {
            userChoice = 0;
            cout << "\nDo you want to hit or hold?\n" << endl;
            cout << "1. Hit" << endl;
            cout << "2. Hold" << endl;
            enterChoiceMessage();
            choiceValidation(userChoice);
            cout << endl;
            if (userChoice == 1) {
                dealCard(deck, userHand, dealerHand, userHand, cardsDealt, userTotal, dealerTotal, hold);
                showingHands(userHand, dealerHand, userTotal, dealerTotal, hold);
                while (userTotal > 21 && highAceCheck(userHand)) {
                    aceCheck(userHand, dealerHand, userTotal, dealerTotal);
                    showingHands(userHand, dealerHand, userTotal, dealerTotal, hold);
                }
                showingHands(userHand, dealerHand, userTotal, dealerTotal, hold);
                if (dealerTotal < 17) {
                    dealCard(deck, userHand, dealerHand, dealerHand, cardsDealt, userTotal, dealerTotal, hold);
                    showingHands(userHand, dealerHand, userTotal, dealerTotal, hold);
                    while (dealerTotal > 21 && highAceCheck(dealerHand)) {
                        aceCheck(userHand, dealerHand, userTotal, dealerTotal);
                        showingHands(userHand, dealerHand, userTotal, dealerTotal, hold);
                    }
                    showingHands(userHand, dealerHand, userTotal, dealerTotal, hold);
                }
                if (userTotal > 21 || (dealerTotal > 21 && !hold)) {
                    hold = true;
                }
                showingHands(userHand, dealerHand, userTotal, dealerTotal, hold);
            }
            else {
                hold = true;
                cout << "You have chosen to stick with what you have" << endl;
                while (dealerTotal < 17) {
                    cout << "\nDealer picks a card..." << endl;
                    addDelay(1000);
                    dealCard(deck, userHand, dealerHand, dealerHand, cardsDealt, userTotal, dealerTotal, hold);
                    showingHands(userHand, dealerHand, userTotal, dealerTotal, hold);
                    while (dealerTotal > 21 && highAceCheck(dealerHand)) {
                        aceCheck(userHand, dealerHand, userTotal, dealerTotal);
                        showingHands(userHand, dealerHand, userTotal, dealerTotal, hold);
                    }
                    showingHands(userHand, dealerHand, userTotal, dealerTotal, hold);
                    addDelay(1000);
                }
                showingHands(userHand, dealerHand, userTotal, dealerTotal, hold);
            }
        }
        addDelay(1000);
        cout << endl;
        result(userTotal, dealerTotal);
        cout << endl;
        reset(userHand, dealerHand, dealerReveal, cardsDealt, userTotal, dealerTotal, hold);
        cout << "Are you ready for another round?\n" << endl;
        cout << "1. Yes" << endl;
        cout << "2. No" << endl;
        enterChoiceMessage();
        userChoice = 0;
        choiceValidation(userChoice);
        if (userChoice == 2) {
            playAgain = false;
        }
    }
    cout << "\nThanks for playing. Goodbye!" << endl;
    return 0;
}

void enterChoiceMessage() {
    cout << "\nPlease enter your choice by the number from the options above: "; 
}

void choiceValidation(int &userChoice) {
    while(!(cin >> userChoice) || (userChoice != 1 && userChoice != 2)) {
        enterChoiceMessage();
        cin.clear(); 
        cin.ignore(numeric_limits<streamsize>::max(),'\n');
    }
}

void rules() {
        cout << "\nTHE RULES OF BLACKJACK" << endl;
        cout << "================================================" << endl;
        cout << "You and the dealer are both dealt two cards each." << endl;
        cout << "You will initially only see one of the dealers cards with the other being shown after you make your move." << endl;
        cout << "You have the choice to stick with the cards you have, or draw another." << endl;
        cout << "If you draw another card and go over the value of 21, you instantly lose." << endl;
        cout << "Alternatively, if you ever get exactly 21 you instantly win, regardless of which cards the dealer has." << endl;
        cout << "If the dealer's hand is below 17, the dealer must draw another card, otherwise they will stick with what they have." << endl;
        cout << "The aim of the game is to get a higher value than the dealer without going over 21." << endl;
        cout << "The values of the cards are the numbers on them with Jacks, Queens and Kings all being worth 10." << endl;
        cout << "An Ace will initially be worth 11 but can alternatively be used as a 1 when required.\n" << endl;
        cout << "Are you ready to play?" << endl;
}

void dealCard(map<string, int> deck, map<string, int> &userHand, map<string, int> &dealerHand, map<string, int> &dealtTo, vector<int> &cardsDealt, int &userTotal, int &dealerTotal, bool &hold) {
    // DECLARING ITERATION
    map<string, int>::iterator it = deck.begin();
    int counter = 0;
    int randomNumber;
    int cnt;
    // GETTING A RANDOM NUMBER FROM 0 - 51
    randomNumber = (rand() % deck.size()) + 0;
    // COUNTING HOW MAY TIMES THE RANDOM NUMBER SHOWS IN CARDS DEALT VECTOR
    cnt = count(cardsDealt.begin(), cardsDealt.end(), randomNumber);
    // MAKING SURE TO LOOP OVER PROCESS UNTIL A RANDOM NUMBER IS CHOSEN THAT ISN'T IN THE CARD DEALT VECTOR
    while (cnt > 0) {
        randomNumber = (rand() % deck.size()) + 0;
        cnt = count(cardsDealt.begin(), cardsDealt.end(), randomNumber);
    }
    // PUSHING THE RANDOM NUMBER INTO THE CARDS DEALT VECTOR
    cardsDealt.push_back(randomNumber);
    // COUNTER IS ESSENTIALLY THE ITERATION NUMBER OF THE NUMBER
    while (it != deck.end()) {
        if (counter == randomNumber) {
            // CREATE IDENTICAL CARD IN SPECIFIED HAND
            dealtTo[it->first] = it->second;
            it++;
            counter++;
        }
    it++;
    counter++;
    }
//    addDelay(1000);
}

void reset(map<string, int> &userHand, map<string, int> &dealerHand, bool &dealerReveal, vector<int> &cardsDealt, int &userTotal, int &dealerTotal, bool &hold) {
    userHand.clear();
    dealerHand.clear();
    dealerReveal = false;
    cardsDealt.clear();
    userTotal = 0;
    dealerTotal = 0;
    hold = false;
}

void addDelay(int milliseconds) {
  this_thread::sleep_for(chrono::milliseconds(milliseconds));
}

void result (int userTotal, int dealerTotal) {
    if ((userTotal > dealerTotal && userTotal < 22) || dealerTotal > 21) {
        if (dealerTotal > 21) {
            cout << "The dealer is BUST!\n" << endl;
        }
        else if (userTotal == 21) {
            cout << "BLACKJACK - You hit 21!\n" << endl;
        }
        cout << "Congratulations, you've won the round!" << endl;
    }
    else if ((dealerTotal > userTotal && dealerTotal < 22) || userTotal > 21) {
        if (userTotal > 21) {
            cout << "BUST - You went over 21\n" << endl;
        }
        cout << "Unlucky, you lose this round" << endl;
    }
    else {
        cout << "This round is a draw" << endl;
    }
}

void showingHands(map<string, int> &userHand, map<string, int> &dealerHand, int &userTotal, int &dealerTotal, bool &hold) {
    system("cls");
    map<string, int>::iterator user = userHand.begin();
    map<string, int>::iterator dealer = dealerHand.begin();
    // SHOWING THE USER HAND
    cout << "USER HAND" << endl;
    cout << "================" << endl;
    userTotal = 0;
    while (user != userHand.end()) {
        cout << user->first << " - " << user->second << endl;
        userTotal += user->second;
        user++;
    }
    cout << "--------------------" << endl;
    cout << "Total score = " << userTotal << endl;
    cout << "--------------------" << endl;
    if (userTotal > 21 || userTotal == 21) {
        return;
    }
    // SHOWING THE DEALER HAND
    cout << "\nDEALER HAND" << endl;
    cout << "================" << endl;
    dealerTotal = 0;
    size_t turnCount = 0;
    bool hiding;
    while (dealer != dealerHand.end()) {
        if (!hold && turnCount == dealerHand.size()-1) {
            cout << "??????? - ?? - " << endl;
            hiding = true;
        }
        else {
            cout << dealer->first << " - " << dealer->second << endl;
            hiding = false;
        }
        dealerTotal += dealer->second;
        dealer++;
        turnCount++;
    }
    cout << "--------------------" << endl;
    cout << "Total score = ";
    hiding ? cout << "??" : cout << dealerTotal;
    cout << endl;
    cout << "--------------------" << endl;
}

void aceCheck(map<string, int> &userHand, map<string, int> &dealerHand, int &userTotal, int &dealerTotal) {
    if (userTotal > 21 || dealerTotal > 21) {
        map<string, int>::iterator user = userHand.begin();
        map<string, int>::iterator dealer = dealerHand.begin();
        int aceCount;
        aceCount = 0;
        while (user != userHand.end()) {
            if (userTotal > 21 && user->second == 11 && aceCount < 1) {
                user->second = 1;
                aceCount++;
            }
            user++;
        }
        aceCount = 0;
        while (dealer != dealerHand.end()) {
            if (dealerTotal > 21 && dealer->second == 11 && aceCount < 1) {
                dealer->second = 1;
                aceCount++;
            }
            dealer++;
        }
    }
}

bool highAceCheck(map<string, int> &turnsHand) {
    map<string, int>::iterator turn = turnsHand.begin();
    while (turn != turnsHand.end()) {
        if (turn->second == 11) {
            return true;
        }
        turn++;
    }
    return false;
}
