#include <iostream>
#include <limits>
#include <string>
#include <vector>
#include <algorithm> 

using namespace std;

void choiceValidation(int &userChoice);
void enterChoiceMessage();
void guessLoop(int &lettersRemaining, string answer, vector<string> &answerChars, vector<char> &lettersGuessed, int &livesRemaining, char &guess, string hint);

int main() {
    string player1;
    string player2;
    string guessing;
    string answer;
    char guess = ' ';
    bool playAgain = true;
    vector<string> answerChars;
    vector<char> lettersGuessed;
    cout << "HANGMAN GAME" << endl;
    cout << "-------------" << endl;
    cout << "Welcome to Hangman! Do you know how to play?\n" << endl;
    cout << "1. Yes" << endl;
    cout << "2. No" << endl;
    int userChoice = 0;
    enterChoiceMessage();
    choiceValidation(userChoice);
    if (userChoice == 2) {
        cout << "\nTHE RULES OF HANGMAN" << endl;
        cout << "------------------------------" << endl;
        cout << "To play Hangman, you need a minimum of two players" << endl;
        cout << "One player enters a word or a phrase and the other player(s) have to guess letter by letter until the answer is revealed" << endl;
        cout << "The player(s) guessing starts with 7 lives and loses a life for every incorrect guess" << endl;
        cout << "A player wins when the word is either guessed correctly or when the guesser has ran out of lives\n" << endl;
        cout << "Are you ready to play?" << endl;
    }
    cout << endl;
    system("pause");
    while (playAgain) {
        vector<string> answerChars;
        vector<char> lettersGuessed;
        string player1;
        string player2;
        string hint;
        string answer;
        int livesRemaining = 8;
        system("cls");
        cout << "Player 1 - Please enter your name: ";
        cin >> player1;
        cout << "Player 2 - Please enter your name: ";
        cin >> player2;
        cout << "\nWho will be guessing this round?\n" << endl;
        cout << "1. " << player1 << endl;
        cout << "2. " << player2 << endl;
        userChoice = 0;
        enterChoiceMessage();
        choiceValidation(userChoice);
        cout << endl;
        userChoice == 1 ? cout << player1 : cout << player2; 
        cout << " will be guessing for this round\n" << endl;
        userChoice == 1 ? cout << player2 : cout << player1; 
        cout << ", please enter your word or phrase: ";
        cin >> answer;
        cout << "\nEnter a hint for ";
        userChoice == 1 ? cout << player1 : cout << player2;
        cout << ": ";
        cin.ignore();
        getline(cin, hint);
        system("cls");
        cout << "Thank you, ";
        userChoice == 1 ? cout << player2 : cout << player1;
        cout << endl << endl;
        userChoice == 1 ? cout << player1 : cout << player2;
        cout << "... it's time to start guessing!\n" << endl;
        system("pause");
        for (size_t i = 0; i < answer.length(); i++) {
            answerChars.push_back("_");
        }
        int lettersRemaining = answer.length();
        guessLoop(lettersRemaining, answer, answerChars, lettersGuessed, livesRemaining, guess, hint);
        cout << "Do you want to play again?\n" << endl;
        cout << "1. Yes" << endl;
        cout << "2. No" << endl;
        enterChoiceMessage();
        userChoice = 0;
        choiceValidation(userChoice);
        if (userChoice == 2) {
            playAgain = false;
        }
    }
    cout << "\nThanks for playing, goodbye!" << endl;
    return 0;
}

void enterChoiceMessage() {
    cout << "\nPlease enter your choice by the number from the options above: "; 
}

void choiceValidation(int &userChoice) {
    while(!(cin >> userChoice) || (userChoice != 1 && userChoice != 2)) {
        enterChoiceMessage();
        cin.clear(); 
        cin.ignore(numeric_limits<streamsize>::max(),'\n');
    }
}

void guessLoop(int &lettersRemaining, string answer, vector<string> &answerChars, vector<char> &lettersGuessed, int &livesRemaining, char &guess, string hint) {
    system("cls");
    for (size_t j = 0;  j < answer.length(); j++) {
        if (guess == answer[j]) {
            answerChars[j] = guess;
            lettersRemaining--;
        }
    }
    size_t incorrect;
    incorrect = 0;
    for (auto c : answer) {
        if (c != guess) {
                incorrect++;
        }
    }
    if (incorrect == answer.length()) {
        livesRemaining--;
    }
    
    cout << "Lives remaining: " << livesRemaining << endl;
    cout << "Letters remaining: " << lettersRemaining << endl << endl;
    cout << "Hint: " << hint << endl << endl;
    for (auto c : answerChars) {
        cout << c << " ";
    }
    if (lettersRemaining == 0) {
        cout << "\n\nCongratulations, you win!\n" << endl;
        return;
    }
    if (livesRemaining == 0) {
        cout << "\n\nUnlucky, you lose!\n" << endl;
        return;
    }
    cout << "\n\nLetters guessed: ";
    for (auto c : lettersGuessed) {
        cout << c << " ";
    }
    cout << "\n\nEnter your guess: ";
    cin >> guess;
    lettersGuessed.push_back(guess);
    guessLoop(lettersRemaining, answer, answerChars, lettersGuessed, livesRemaining, guess, hint);
}
