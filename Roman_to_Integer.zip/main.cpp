#include <iostream>
#include <limits>
#include <map>
#include <string>
#include <vector>
#include<bits/stdc++.h> 

using namespace std;

int numCalc(int value);

int main() {
    
    // Create a map of chars and integers - Char will be roman numeral, int will be its corresponding value
    map<char, int> numeralsMap;
 
    // Insert some values into the map
    numeralsMap['I'] = 1; numeralsMap['V'] = 5; numeralsMap['X'] = 10; numeralsMap['L'] = 50; numeralsMap['C'] = 100; numeralsMap['D'] = 500; numeralsMap['M'] = 1000;
    
    cout << "Welcome to the Roman numeral to integer converter\n" << endl;
    cout << "Roman Numerals make use of the following characters: I, V, X, L, C, D & M\n" << endl;
    string romanNumerals;
    size_t counter = 0;
    bool firstLoop = true;
    map<char, int>::iterator it = numeralsMap.begin();
    // Ensuring there are no incorrect characters submitted by the user
    do {
        counter = 0;
        if (firstLoop) {
            cout << "Please enter the Roman numeral you would like to convert: ";
        }
        else {
            cout << "Invalid Roman Numeral character detected. Try Again: ";
        }
        cin >> romanNumerals;
        transform(romanNumerals.begin(), romanNumerals.end(), romanNumerals.begin(), ::toupper);
        while(it != numeralsMap.end()) {
            for (size_t i = 0; i < romanNumerals.length(); i++) {
                if (romanNumerals[i] == it->first) {
                    counter++;
                }
            }
            it++;
        }
        it = numeralsMap.begin();
        firstLoop = false;
    } while (counter != romanNumerals.length());
    vector<char> userRomanNumerals;
    // Pushing each letter from romanNumerals string into userRomanNumerals vector to create characters
    for (size_t i = 0; i < romanNumerals.length(); i++) {
        userRomanNumerals.push_back(romanNumerals[i]);
    }
    // Declaring iteration of numeralsMap
    int numTotal = 0;
    it = numeralsMap.begin();
    for (size_t i = 0; i < userRomanNumerals.size(); i++) {
        while(it != numeralsMap.end()) {
            if(userRomanNumerals[i] == it->first) {
                //Turning the value of I into a negative of that number if I is followed by X or V
                if(userRomanNumerals[i] == 'I' && (userRomanNumerals[i+1] == 'X' || userRomanNumerals[i+1] == 'V')) {
                    numTotal += numCalc(it->second);
                }
                //Turning the value of X into a negative of that number if X is followed by L or C
                else if(userRomanNumerals[i] == 'X' && (userRomanNumerals[i+1] == 'L' || userRomanNumerals[i+1] == 'C')) {
                    numTotal += numCalc(it->second);
                }
                //Turning the value of C into a negative of that number if C is followed by D or M
                else if(userRomanNumerals[i] == 'C' && (userRomanNumerals[i+1] == 'D' || userRomanNumerals[i+1] == 'M')) {
                    numTotal += numCalc(it->second);
                }
                // If none of the above statements apply -> Just take values of the char from numeralsMap and add them together
                else {
                    numTotal += it->second;
                }
            }
            it++;
        }
        // Resetting the iterator
        it = numeralsMap.begin();
    }
    cout << "\nThe Roman Numeral of " << romanNumerals << " is equal to " << numTotal << endl;
    return 0;
}

int numCalc(int value) {
    return value - value*2;
}
