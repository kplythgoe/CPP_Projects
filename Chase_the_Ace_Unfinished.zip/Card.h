#ifndef __CARD_H__
#define __CARD_H__
#include <string>
#include <iostream>

using namespace std;

class Card
{
    int value;
    string name, colour;
public:
    Card(int value, string name, string colour);
    Card(const Card &source);
    ~Card();
    void display() const;

};

#endif // __CARD_H__
