#include "Card.h"

Card::Card(int value, string name, string colour)
: value(value), name(name), colour(colour){
}

Card::Card(const Card &source)
: Card(source.value, source.name, source.colour){
}

Card::~Card()
{
}

void Card::display() const {
    cout << value << " - " << name << " - " << colour << endl;
}

