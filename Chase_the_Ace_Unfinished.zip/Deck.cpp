#include "Deck.h"

Deck::Deck()
{
}

Deck::~Deck()
{
}

void Deck::add_card(int value, string name, string colour) {
    Card temp {value, name, colour};
    deck.push_back(temp);
}

void Deck::display() const {
    for(const auto &card: deck) {
        card.display();
    }
}

