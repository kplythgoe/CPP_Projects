#include "Deck.h"

Deck::Deck()
{
}

Deck::~Deck()
{
}

void Deck::add_card(int value, string name, string colour) {
    Card temp {value, name, colour};
    deck.push_back(temp);
}

void Deck::display() const {
    for(const auto &card: deck) {
        card.display();
    }
}

vector<Card>  Deck::getVec() const {
    return deck;
}

void Deck::deal(Deck cards, int randomNumber) {
    vector<Card> pack = cards.getVec();
    deck.push_back(pack[randomNumber]);
}

int Deck::sizeOfDeck() const {
    return deck.size();
}

