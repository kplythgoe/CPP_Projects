#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <limits>
#include <chrono>
#include <thread>
#include <sstream>
#include <algorithm>
#include "Deck.h"

using namespace std;

void rules();
void enterChoiceMessage();
void choiceValidation(int &userChoice);

int main() {
    // CREATING DECK OBJECT
    Deck deck;
    int userChoice, players;
    string playerName;
    srand((unsigned) time(0));
    int randomNumber;
    // READING FROM FILE --> CHECKING IT'S WORKING
    ifstream in_file {"Chase_the_Ace/cards.txt", ios::in };
    if (in_file.is_open()) {
    } else {
       cout << "Could not find file" << endl;
    }
    
    // READING FROM FILE AND INSERTING INTO DECK OBJECT
    string line = "";
    while(getline(in_file, line)) {
        int value;
        string name, colour;
        string tempString = "";
        stringstream inputString(line);
        
        getline(inputString, tempString, ',');
        value = atoi(tempString.c_str());
        getline(inputString, name, ',');
        getline(inputString, colour, ',');
        
        deck.add_card(value, name, colour);
    }
    
    // STARTING GAME
    cout << "CHASE THE ACE" << endl;
    cout << "==============" << endl;
    cout << "\nDo you know how to play Chase the Ace?" << endl;
    cout << "\n1. Yes" << endl;
    cout << "2. No" << endl;
    enterChoiceMessage();
    choiceValidation(userChoice);
    if (userChoice == 2) {
        cout << endl;
        rules();
    }
    cout << endl;
    system("pause");
    system("cls");
    cout << "Please enter your name: ";
    cin >> playerName;
    cout << "Enter the number of players you want to play against: ";
    cin >> players;
    players++;
    // CREATING DECKS FOR NUMBER OF PLAYERS
    vector<Deck> allPlayers;
    for (int i = 0; i < players; i++)  {
        Deck playerDeck;
        allPlayers.push_back(playerDeck);
    }
    cout << "There are " << allPlayers.size() << " players including yourself\n\n"; 
    system("pause");
    system("cls");
    // DEALING THE DECK
    vector<int> usedCards;
    int cnt;
    while (usedCards.size() != deck.sizeOfDeck()) {
        for(int i = 0; i < players; i++) {
            if (usedCards.size() != deck.sizeOfDeck()) {
                randomNumber = (rand() % deck.sizeOfDeck()) + 0;
                cnt = count(usedCards.begin(), usedCards.end(), randomNumber);
                if (cnt > 0) {
                    randomNumber = (rand() % deck.sizeOfDeck()) + 0;
                    cnt = count(usedCards.begin(), usedCards.end(), randomNumber); 
                }
                usedCards.push_back(randomNumber);
                allPlayers[i].deal(deck, randomNumber);
            }
        }
    }
    
    //CHECKING FOR INITIAL MATCHES
    
    return 0;
}

void enterChoiceMessage() {
    cout << "\nPlease enter your choice by the number from the options above: "; 
}
void choiceValidation(int &userChoice) {
    while(!(cin >> userChoice) || (userChoice != 1 && userChoice != 2)) {
        enterChoiceMessage();
        cin.clear(); 
        cin.ignore(numeric_limits<streamsize>::max(),'\n');
    }
}
void rules() {
    cout << "\nRULES OF CHASE THE ACE" << endl;
    cout << "==========================" << endl;
    cout << "A regular deck of cards (excluding the Ace of Clubs) will be dealt to the players" << endl;
    cout << "In their initial hands, players will remove all matches they currently have" << endl;
    cout << "A match is when two cards share the same value and are the same colour" << endl;
    cout << "An example of a match would be King of Hearts and King of Diamons (King and Red)" << endl;
    cout << "When all matches have been discarded a player will be randomly selected to go first" << endl;
    cout << "This player will pick a card from the next player" << endl;
    cout << "If this card is a match with a card the player already has, the match will be discarded" << endl;
    cout << "The next player will take their turn and repeat the process" << endl << endl;
    cout << "Eventually, one player will be left with the Ace of Spades... This player is the loser" << endl;
}
