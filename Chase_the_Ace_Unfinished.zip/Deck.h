#ifndef __DECK_H__
#define __DECK_H__
#include <string>
#include <vector>
#include "Card.h"

using namespace std;

class Deck
{
    vector<Card> deck;
public:
    Deck();
    ~Deck();
    void add_card(int value, string name, string colour);
    void display() const;
};

#endif // __DECK_H__
